"""RSS/Atom polling with conditional requests and bounded XML parsing."""
from __future__ import annotations

import os
import json
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Any

from .models import SourceDefinition, clean_text, normalize_timestamp, stable_source_id


DEFAULT_SOURCES = (
    ("BBC World", "https://feeds.bbci.co.uk/news/world/rss.xml", "Main News Feed"),
    ("BBC Asia", "https://feeds.bbci.co.uk/news/world/asia/rss.xml", "Main News Feed"),
    ("BBC Technology", "https://feeds.bbci.co.uk/news/technology/rss.xml", "Technology"),
    ("BBC Business", "https://feeds.bbci.co.uk/news/business/rss.xml", "Business"),
    ("BBC Science", "https://feeds.bbci.co.uk/news/science_and_environment/rss.xml", "Science"),
    ("BBC Health", "https://feeds.bbci.co.uk/news/health/rss.xml", "Health"),
    ("The Guardian World", "https://www.theguardian.com/world/rss", "Main News Feed"),
    ("The Guardian Technology", "https://www.theguardian.com/technology/rss", "Technology"),
    ("The Guardian Science", "https://www.theguardian.com/science/rss", "Science"),
    ("The Guardian Business", "https://www.theguardian.com/business/rss", "Business"),
    ("The Guardian Environment", "https://www.theguardian.com/environment/rss", "Science"),
    ("NPR World", "https://feeds.npr.org/1004/rss.xml", "Main News Feed"),
    ("NPR Technology", "https://feeds.npr.org/1019/rss.xml", "Technology"),
    ("NPR Science", "https://feeds.npr.org/1007/rss.xml", "Science"),
    ("Al Jazeera", "https://www.aljazeera.com/xml/rss/all.xml", "Main News Feed"),
    ("NYT World", "https://rss.nytimes.com/services/xml/rss/nyt/World.xml", "Main News Feed"),
    ("NYT Technology", "https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml", "Technology"),
    ("Ars Technica", "https://feeds.arstechnica.com/arstechnica/index", "Technology"),
    ("The Verge", "https://www.theverge.com/rss/index.xml", "Technology"),
    ("MIT Technology Review", "https://www.technologyreview.com/feed/", "Technology"),
    ("Hacker News", "https://hnrss.org/frontpage", "Technology"),
    ("NASA Breaking News", "https://www.nasa.gov/rss/dyn/breaking_news.rss", "Space"),
    ("NASA Image of the Day", "https://www.nasa.gov/rss/dyn/lg_image_of_the_day.rss", "Space"),
    ("ESA", "https://www.esa.int/rssfeed/Our_Activities/Space_News", "Space"),
    ("Nature News", "https://www.nature.com/nature.rss", "Science"),
    ("ScienceDaily", "https://www.sciencedaily.com/rss/all.xml", "Science"),
    ("Krebs on Security", "https://krebsonsecurity.com/feed/", "Security"),
    ("The Record", "https://therecord.media/feed", "Security"),
    ("CISA Alerts", "https://www.cisa.gov/cybersecurity-advisories/all.xml", "Security"),
    ("CoinDesk", "https://www.coindesk.com/arc/outboundfeeds/rss/", "Finance"),
    ("Investing.com", "https://www.investing.com/rss/news.rss", "Finance"),
    ("OpenAI News", "https://openai.com/news/rss.xml", "AI Watch"),
    ("Google DeepMind", "https://deepmind.google/blog/rss.xml", "AI Watch"),
    ("Hugging Face Blog", "https://huggingface.co/blog/feed.xml", "AI Watch"),
    ("Thailand PBS World", "https://www.thaipbsworld.com/feed/", "Thailand Focus"),
    ("Bangkok Post", "https://www.bangkokpost.com/rss/data/news.xml", "Thailand Focus"),
)


@dataclass(frozen=True)
class FetchResult:
    candidates: list[dict[str, Any]]
    etag: str = ""
    last_modified: str = ""
    not_modified: bool = False


def configured_sources(raw: str | None = None) -> list[SourceDefinition]:
    value = raw if raw is not None else os.environ.get("DISCOVERY_SERVICE_SOURCES", "")
    pairs: list[tuple[str, str, str]] = []
    source_file = os.environ.get("DISCOVERY_SERVICE_SOURCES_FILE", "").strip()
    if not value.strip() and source_file:
        try:
            with open(source_file, "r", encoding="utf-8") as handle:
                configured = json.load(handle)
            if isinstance(configured, list):
                for entry in configured:
                    if not isinstance(entry, dict):
                        continue
                    name = str(entry.get("name") or "").strip()
                    url = str(entry.get("url") or entry.get("endpoint") or "").strip()
                    category = str(entry.get("category") or "Main News Feed").strip()
                    if name and url:
                        pairs.append((name, url, category or "Main News Feed"))
        except (OSError, ValueError, TypeError):
            pairs = []
    if not pairs and value.strip():
        for entry in value.split(","):
            name, separator, rest = entry.partition("|")
            url, separator2, category = rest.partition("|")
            if separator and name.strip() and url.strip():
                pairs.append((name.strip(), url.strip(), category.strip() if separator2 and category.strip() else "Main News Feed"))
    elif not pairs:
        pairs = list(DEFAULT_SOURCES)
    return [SourceDefinition(stable_source_id(name, url), name, url, category) for name, url, category in pairs if url.startswith(("http://", "https://"))]


def _local_name(tag: object) -> str:
    return str(tag).rsplit("}", 1)[-1].casefold()


def _child_text(element: ET.Element, *names: str) -> str:
    wanted = {name.casefold() for name in names}
    for child in list(element):
        if _local_name(child.tag) in wanted:
            return clean_text("".join(child.itertext()), 20_000)
    return ""


def _link(element: ET.Element) -> str:
    for child in list(element):
        if _local_name(child.tag) != "link":
            continue
        href = child.attrib.get("href")
        if href:
            return href.strip()
        value = clean_text("".join(child.itertext()), 4_000)
        if value:
            return value
    return ""


def _image(element: ET.Element) -> str:
    for child in element.iter():
        if _local_name(child.tag) in {"content", "thumbnail", "enclosure"}:
            value = child.attrib.get("url") or child.attrib.get("href") or ""
            if value and ("image" in str(child.attrib.get("type", "")) or _local_name(child.tag) != "enclosure"):
                return value.strip()
    return ""


def fetch_feed(source: SourceDefinition, *, timeout: float = 20.0, item_limit: int = 40, etag: str = "", last_modified: str = "") -> FetchResult:
    headers = {"Accept": "application/rss+xml, application/atom+xml, application/xml, text/xml;q=0.9, */*;q=0.5", "User-Agent": "Ariadne Discovery Engine/0.1"}
    if etag:
        headers["If-None-Match"] = etag
    if last_modified:
        headers["If-Modified-Since"] = last_modified
    request = urllib.request.Request(source.url, headers=headers)
    try:
        response_context = urllib.request.urlopen(request, timeout=max(1.0, float(timeout)))
    except urllib.error.HTTPError as exc:
        if exc.code == 304:
            return FetchResult([], etag, last_modified, True)
        raise
    with response_context as response:
        raw = response.read(4_000_000)
        response_etag = str(response.headers.get("ETag") or "")
        response_modified = str(response.headers.get("Last-Modified") or "")
        charset = response.headers.get_content_charset() or "utf-8"
    root = ET.fromstring(raw.decode(charset, errors="replace"))
    candidates: list[dict[str, Any]] = []
    for element in [item for item in root.iter() if _local_name(item.tag) in {"item", "entry"}][: max(1, min(int(item_limit), 100))]:
        title = _child_text(element, "title")
        url = _link(element)
        summary = _child_text(element, "encoded", "description", "summary", "subtitle", "content")
        published = _child_text(element, "pubdate", "published", "updated", "date", "issued")
        if not title or not url:
            continue
        candidates.append({"title": title, "url": url, "summary": summary, "content": summary, "source_id": source.source_id, "source_name": source.name, "source_url": source.url, "category": source.category, "published_at": normalize_timestamp(published), "image_url": _image(element)})
    return FetchResult(candidates, response_etag, response_modified)


__all__ = ["DEFAULT_SOURCES", "FetchResult", "SourceDefinition", "configured_sources", "fetch_feed"]
