import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from discovery_service.clustering import cluster_articles, diversify, rank_stories, story_from_cluster
from discovery_service.engine import DiscoveryEngine
from discovery_service.feeds import FetchResult, SourceDefinition, configured_sources
from discovery_service.models import Article, canonical_url


def article(url, title, summary, source, category="Main News Feed", published_at="2026-09-10T06:00:00+00:00"):
    return Article.from_candidate({"url": url, "title": title, "summary": summary, "content": summary, "source_id": source.lower().replace(" ", "-"), "source_name": source, "source_url": "https://" + source.lower().replace(" ", "") + ".example/", "category": category, "published_at": published_at})


class DiscoveryTests(unittest.TestCase):
    def test_canonical_url_removes_tracking_without_merging_real_query(self):
        self.assertEqual(canonical_url("https://Example.com/story/?utm_source=x&id=7#fragment"), "https://example.com/story?id=7")

    def test_related_reports_cluster_and_copied_text_is_not_counted_as_independent(self):
        first = article("https://one.example/apple", "Apple launches a foldable iPhone", "Apple announced a new foldable phone at an event.", "One News")
        second = article("https://two.example/apple", "Apple unveils foldable iPhone at event", "Apple announced a new foldable phone at an event.", "Two News")
        third = article("https://three.example/apple", "Apple foldable phone reviewed", "Independent analysis of Apple's new foldable phone and its price.", "Three News")
        clusters = cluster_articles([first, second, third])
        self.assertEqual(len(clusters), 1)
        story = story_from_cluster(clusters[0])
        self.assertEqual(story["article_count"], 3)
        self.assertEqual(story["source_count"], 2)
        self.assertEqual(len(story["evidence"]), 3)

    def test_diversity_prevents_one_category_consuming_every_slot(self):
        stories = rank_stories([{"story_id": f"story-{i}", "title": str(i), "summary": "", "category": "Technology" if i < 5 else "Science", "published_at": "2026-09-10T06:00:00+00:00", "source_count": 1, "article_count": 1} for i in range(6)])
        result = diversify(stories, limit=4)
        self.assertEqual([item["category"] for item in result[:2]], ["Science", "Technology"])

    def test_engine_refresh_persists_stories_and_reports_signal_push_failure(self):
        with tempfile.TemporaryDirectory() as directory:
            source = SourceDefinition("source-test", "Test Feed", "https://example.test/feed.xml", "Technology")
            with patch.dict("os.environ", {"DISCOVERY_SERVICE_SIGNAL_SERVICE_URL": "http://127.0.0.1:9", "DISCOVERY_SERVICE_REFRESH_SECONDS": "900"}, clear=False), patch("discovery_service.engine.fetch_feed", return_value=FetchResult([{"url": "https://example.test/story", "title": "A useful technology story", "summary": "A short report.", "published_at": "2026-09-10T06:00:00Z", "source_id": "source-test", "source_name": "Test Feed", "source_url": "https://example.test/feed.xml", "category": "Technology"}])):
                engine = DiscoveryEngine(str(Path(directory) / "discovery.sqlite3"), sources=[source])
                try:
                    result = engine.refresh()
                    self.assertTrue(result["ok"])
                    self.assertEqual(result["story_count"], 1)
                    self.assertFalse(result["push"]["ok"])
                    self.assertEqual(engine.stories(10)[0]["source_count"], 1)
                finally:
                    engine.close()

    def test_source_file_is_supported_for_large_catalogues(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "sources.json"
            path.write_text(json.dumps([{"name": "One", "url": "https://one.example/feed", "category": "Science"}]), encoding="utf-8")
            with patch.dict("os.environ", {"DISCOVERY_SERVICE_SOURCES": "", "DISCOVERY_SERVICE_SOURCES_FILE": str(path)}, clear=False):
                result = configured_sources()
            self.assertEqual([(item.name, item.category) for item in result], [("One", "Science")])

    def test_repeated_url_from_two_feeds_keeps_both_source_observations(self):
        with tempfile.TemporaryDirectory() as directory:
            from discovery_service.store import DiscoveryStore

            store = DiscoveryStore(Path(directory) / "discovery.sqlite3")
            try:
                store.upsert_articles([
                    article("https://story.example/item", "A story", "The same report body.", "One News"),
                    article("https://story.example/item", "A story", "The same report body.", "Two News"),
                ])
                clusters = cluster_articles(store.recent_articles())
                story = story_from_cluster(clusters[0])
                self.assertEqual(story["article_count"], 1)
                self.assertEqual(story["source_names"], ["One News", "Two News"])
            finally:
                store.close()


if __name__ == "__main__":
    unittest.main()
